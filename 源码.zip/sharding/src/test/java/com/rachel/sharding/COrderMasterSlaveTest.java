package com.rachel.sharding;

import com.rachel.sharding.dao.COrderRepository;
import com.rachel.sharding.entity.COrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Repeat;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Random;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = ShardingApplication.class)
public class COrderMasterSlaveTest {

    @Resource
    private COrderRepository orderRepository;

    @Test
    @Repeat(100)
    public void testAddCOrder(){
        COrder cOrder = new COrder();
        cOrder.setDel(false);
        cOrder.setUserId(new Random().nextInt(10));
        cOrder.setCompanyId(new Random().nextInt(10));
        cOrder.setPublishUserId(954522441);
        cOrder.setPositionId(784545646);
        cOrder.setResumeType(0);
        cOrder.setStatus("WAIT");
        cOrder.setCreateTime(new Date());
        cOrder.setUpdateTime(new Date());
        orderRepository.save(cOrder);
    }

    @Test
    public void testFindCOrder(){
        List<COrder> list = orderRepository.findByCompanyId(new Random().nextInt(10));
        list.forEach(cOrder ->{
            System.out.println(cOrder.toString());
        });
    }
}
