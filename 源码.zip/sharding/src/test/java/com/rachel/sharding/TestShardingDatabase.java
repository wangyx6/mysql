package com.rachel.sharding;


import com.rachel.sharding.dao.PositionRepository;
import com.rachel.sharding.entity.PositionPO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = ShardingApplication.class)
public class TestShardingDatabase {


    @Resource
    private PositionRepository positionRepository;

    @Test
    public void testAdd(){
        for(int i=1; i<=20; i++){
            PositionPO positionPO = new PositionPO();
//            positionPO.setId(i);
            positionPO.setName("lagou" + i);
            positionPO.setSalary("2000000");
            positionPO.setCity("杭州");
            positionRepository.save(positionPO);
        }
    }
}
