package com.rachel.sharding.dao;

import com.rachel.sharding.entity.PositionPO;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PositionRepository extends JpaRepository<PositionPO, Long> {

}
