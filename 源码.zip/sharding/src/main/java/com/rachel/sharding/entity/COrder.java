package com.rachel.sharding.entity;

import lombok.Data;
import lombok.ToString;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "c_order")
@Data
@ToString
public class COrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "is_del")
    private boolean isDel;

    @Column(name = "user_id")
    private int userId;

    @Column(name = "company_id")
    private int companyId;

    @Column(name = "publish_user_id")
    private int publishUserId;

    @Column(name = "position_id")
    private int positionId;

    @Column(name = "resume_type")
    private int resumeType;

    private String status;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "update_time")
    private Date updateTime;




}
