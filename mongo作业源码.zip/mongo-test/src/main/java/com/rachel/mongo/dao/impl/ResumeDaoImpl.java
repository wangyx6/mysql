package com.rachel.mongo.dao.impl;

import com.rachel.mongo.dao.ResumeDao;
import com.rachel.mongo.po.Resume;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("resumeDao")
public class ResumeDaoImpl implements ResumeDao {

    @Autowired
    private MongoTemplate mongoTemplate;


    @Override
    public void insert(Resume resume) {
        mongoTemplate.insert(resume, "lagou_resume_datas");
    }

    @Override
    public List<Resume> findAll() {
        return mongoTemplate.findAll(Resume.class, "lagou_resume_datas");
    }
}
