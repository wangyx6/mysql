package com.rachel.mongo.dao;

import com.rachel.mongo.po.Resume;

import java.util.List;

public interface ResumeDao {

    void insert(Resume resume);

    List<Resume> findAll();
}
