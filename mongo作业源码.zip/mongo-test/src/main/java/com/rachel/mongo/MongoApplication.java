package com.rachel.mongo;

import com.rachel.mongo.dao.ResumeDao;
import com.rachel.mongo.po.Resume;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import java.util.Date;
import java.util.List;

@SpringBootApplication
public class MongoApplication {

    public static void main(String[] args) {
        ApplicationContext applicationContext = SpringApplication.run(MongoApplication.class, args);
        ResumeDao resumeDao = applicationContext.getBean(ResumeDao.class);
        List<Resume> all = resumeDao.findAll();
        all.forEach(resume -> {
                    System.out.println(resume.toString());
                }
        );
//        Resume resume = new Resume();
//        resume.setCity("hangzhou");
//        resume.setBirthday(new Date());
//        resume.setExpectSalary(20000);
//        resume.setName("test1");
//        resumeDao.insert(resume);
    }

}
