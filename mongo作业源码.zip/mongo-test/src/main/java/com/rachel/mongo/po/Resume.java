package com.rachel.mongo.po;

import lombok.Data;
import lombok.ToString;

import java.util.Date;

@Data
@ToString
public class Resume {
    private String id;
    private String name;
    private String city;
    private Date birthday;
    private  double  expectSalary;
}
